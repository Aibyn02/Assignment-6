package com.company;

public class Main {

    public static void main(String[] args) {
        PostOffice PO = new PostOffice();

        PO.addJournal("First Journal");
        PO.addJournal("Second Journal");

        Observer firstSubscriber = new Subscriber("Aibyn");
        Observer secondSubscriber = new Subscriber("Aidyn");

        PO.addObserver(firstSubscriber);
        PO.addObserver(secondSubscriber);

        PO.addJournal("Third Journal");

    }
}
