package com.company;

import java.util.List;

public class Subscriber implements Observer {
    String name;

    public Subscriber(String name){
        this.name = name;
    }

    @Override
    public void handleEvent(List<String> journals) {
        System.out.println("Dear, " + name + ", we got your journals.\nAfter some time, we will deliver this journals to you!!!\n" + journals);
        System.out.println("==================================");
    }

}
