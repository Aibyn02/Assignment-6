package com.company;

import com.company.Strategy.IMoveStrategy;

public class Character{
    private IMoveStrategy iMoveStrategy;

    public Character(IMoveStrategy iMoveStrategy){
        this.iMoveStrategy = iMoveStrategy;
    }
    public void move(){
        this.iMoveStrategy.move();
    }

    public void setiMoveStrategy(IMoveStrategy iMoveStrategy){
        this.iMoveStrategy = iMoveStrategy;
    }

}
