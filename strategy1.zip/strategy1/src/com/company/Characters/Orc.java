package com.company.Characters;

import com.company.Character;
import com.company.ICharacter;
import com.company.Strategy.WalkStrategy;

public class Orc extends Character implements ICharacter {
    public Orc(){
        super(new WalkStrategy());
    }

    @Override
    public void SayYourType() {
        System.out.println("I am an Orc");
    }
}
