package com.company.Characters;

import com.company.Character;
import com.company.ICharacter;
import com.company.Strategy.WalkStrategy;

public class Pegasus extends Character implements ICharacter {
    public Pegasus(){
        super(new WalkStrategy());
    }

    @Override
    public void SayYourType() {
        System.out.println("I am a Pegasus");
    }
}
