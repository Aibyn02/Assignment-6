package com.company.Characters;

import com.company.Character;
import com.company.ICharacter;
import com.company.Strategy.WalkStrategy;

public class Vampire extends Character implements ICharacter {
    public Vampire(){
        super(new WalkStrategy());
    }

    @Override
    public void SayYourType() {
        System.out.println("I am a Vampire");
    }
}
