package com.company;

public interface ICharacter {
    public void SayYourType();
}
