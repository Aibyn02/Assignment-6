package com.company;

import com.company.Characters.*;
import com.company.Strategy.FlyAndWalkStrategy;

public class Main {

    public static void main(String[] args) {
        System.out.println("====================");
        Troll T = new Troll();
        T.SayYourType();
        T.move();

        System.out.println("====================");
        Orc O = new Orc();
        O.SayYourType();
        O.move();

        System.out.println("====================");
        Pegasus P = new Pegasus();
        P.SayYourType();
        P.move();
        System.out.println("//Here P learned to fly");
        P.setiMoveStrategy(new FlyAndWalkStrategy());
        P.move();

        System.out.println("====================");
        Elve E = new Elve();
        E.SayYourType();
        E.move();

        System.out.println("====================");
        Vampire V = new Vampire();
        V.SayYourType();
        V.move();
        System.out.println("//Here V improved his abilities and learned to fly");
        V.setiMoveStrategy(new FlyAndWalkStrategy());
        V.move();
        System.out.println("====================");
    }
}
