package com.company.Strategy;

import com.company.Strategy.IMoveStrategy;

public class FlyAndWalkStrategy implements IMoveStrategy {
    @Override
    public void move() {
        System.out.println("I can Walk and Fly");
    }
}
