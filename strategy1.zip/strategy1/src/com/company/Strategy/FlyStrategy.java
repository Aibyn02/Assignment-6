package com.company.Strategy;

import com.company.Strategy.IMoveStrategy;

public class FlyStrategy implements IMoveStrategy {
    @Override
    public void move() {
        System.out.println("I can Fly, but I can't Walk");
    }
}
