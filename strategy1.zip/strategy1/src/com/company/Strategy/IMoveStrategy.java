package com.company.Strategy;

public interface IMoveStrategy {
    public void move();
}
