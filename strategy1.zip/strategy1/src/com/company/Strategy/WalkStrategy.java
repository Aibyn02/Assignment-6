package com.company.Strategy;

import com.company.Strategy.IMoveStrategy;

public class WalkStrategy implements IMoveStrategy {
    @Override
    public void move() {
        System.out.println("I can Walk, but I can't Fly");
    }
}
